public class Googleplay {
    public static class Googleplay {
        private String ShortDescription;
        private String Filesize;
        private String Icon;
        private int Nama;

        public Googleplay(){
        }

        public Googleplay (String ShortDescription,String filesize,String icon, int Nama){
            this.ShortDescription = ShortDescription;
            this.Filesize = filesize;
            this.Icon =icon;
            this.Nama = Nama;
        }

        public String getShortDescription() {
            return this.ShortDescription;
        }

        public void setShortDescription(String ShortDescription) {
            this.ShortDescription = ShortDescription;
        }

        public String getFilesize() {
            return this.Filesize;
        }

        public void setFilesize(String Filesize) {
            this.Filesize = Filesize;
        }

        public String getIcon() {
            return this.Icon;
        }

        public void setIcon(String Icon) {
            this.Icon = Icon;
        }

        public int Nama() {
            return this.Nama;
        }

        public void setNama(int Nama) {
            this.Nama = Nama;
        }
    }
}
}
